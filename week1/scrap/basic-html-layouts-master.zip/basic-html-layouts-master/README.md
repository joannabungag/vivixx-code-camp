# Basic HTML Layouts (Not yet responsive)
Here are the basic HTML layouts using CSS. Checkout [my blog](http://blog.jeffreynerona.com) for a little bit of the process.

## Three Boxes
![jeffreynerona|three-boxes](https://raw.githubusercontent.com/jeffreynerona/basic-html-layouts/master/screenshot/three-boxes.jpg)

## Five Boxes
![jeffreynerona|three-boxes](https://raw.githubusercontent.com/jeffreynerona/basic-html-layouts/master/screenshot/five-boxes.jpg)

## Advanced Grid
![jeffreynerona|three-boxes](https://raw.githubusercontent.com/jeffreynerona/basic-html-layouts/master/screenshot/advanced-grid.jpg)